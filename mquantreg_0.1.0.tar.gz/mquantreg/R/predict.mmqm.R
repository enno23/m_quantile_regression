#' Predict method for Pseudo mixed M-quantile Model Fits
#'
#' Predicted values for class "mmqm".
#'
#' @param object	mq object, a result of  \code{\link{mq}}.
#' @param newdata	An optional data frame in which to look for variables with which to predict. If omitted, the fitted values are used.
#' @return Returns a vector of predicted values.
#' @export
#' @seealso \code{\link{mmqm}}
#' @references Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71.
#'
#' Chambers, R. and N. Tzavidis (2006): \emph{M-quantile models for small area estimation},
#' Biometrika, 93, 255-268.
#' %@author Enno Tammena \email{tammenae@@hu-berlin.de}
#' @examples
#' # use first 200 observations in chickweight data to predict remaining observations:
#' mmqm_model <-  mmqm(weight ~Time, data=ChickWeight[1:200,], domains="Diet")
#' predict(mmqm_model, ChickWeight[-c(1:200),])


predict.mmqm <- function (object, newdata, na.action = na.pass, ...)
{
  if(inherits(object,"mmqm")==FALSE) stop("Object is not of class mmqm")
  if (missing(newdata)) { newdata<- object$df}
  rowid<-1:nrow(newdata)
  newdata <- as.data.frame(cbind(y=NA, newdata,rowid))
  oldnames <- colnames(object$x)[!colnames(object$x) %in% "(Intercept)"]
  newnames <- colnames(newdata)
  if(any(!oldnames %in% newnames)==TRUE) stop("one or more variable names do not match")
  x <- cbind(model.matrix(formula(paste("~",strsplit(as.character(formula(object$call)),"~")[[3]])), newdata), newdata[object$dom.name],  newdata["rowid"])
  splitx <- split(x, x[object$dom.name])
  splitb <- split(object$area.coef, object$area.coef[object$dom.name])

  pred<-NULL
  for(i in 1:length(splitx)){
    X <- as.matrix(splitx[[i]][!colnames(splitx[[i]]) %in% c(object$dom.name,"rowid")])
    #ensure order of domains
    b <- splitb[[names(splitx[i])]]
    #if pop domain doesn't excist in sample data, give it the 0.5 quantile coefficients (see rao).
    if(is.null(b)||nrow(b)==0){
    b <- object$all.coef[object$all.coef$tau==0.5,]
    b <- b[!colnames(b)=="tau"]
    b <- t(as.matrix(b))
    y_hat <- as.numeric(X%*%b)
    } else{
    b <- b[!colnames(b)==object$dom.name]
    b <- t(as.matrix(b))
    y_hat <- as.numeric(X%*%b)
    }
    df_t <- cbind(y_hat,splitx[[i]])
    pred <- rbind(pred, df_t)
  }
  #sort
  y_hat<-pred[ order(pred$rowid), ]$y_hat
  return(y_hat)
  }

