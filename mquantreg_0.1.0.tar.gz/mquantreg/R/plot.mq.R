#' Residual plot for an mq object.
#'
#'Creates  a  plot of  residuals versus fitted values.
#'
#' @param object	mq object, a result of  \code{\link{mq}}.

#' @return Returns a list of one plot per tau.
#' @export
#' @seealso \code{\link{mq}}
#' @references Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71.
#'
#' Chambers, R. and N. Tzavidis (2006): \emph{M-quantile models for small area estimation},
#' Biometrika, 93, 255-268.
#' %@author Enno Tammena \email{tammenae@@hu-berlin.de}
#' @examples
#' plot(mq(stack.loss ~ ., stackloss, t=c(0.25,0.5,0.75)))

plot.mq <- function(object) {
  if(inherits(object,"mq")==FALSE) stop("Object is not of class mq")
  rvf <- list()
  for(t in 1:length(object$tau.values)){
    plot(object$fitted.values[,t],
         object$residuals[,t],
         sub=object$call,
         main=paste("Residuals vs Fitted for t=",object$tau.values[t]),
         ylab="Residuals",
         xlab="Fitted Values")
  }
}
