#' Printing Linear M-quantile Model Fits
#'
#' Printing method for class "mq".
#'
#' @param object	mq object, a result of  \code{\link{mq}}.

#' @return The function determines the printing behaviour for  the  \code{\link{mq}} object.
#' @export
#' @seealso \code{\link{mq}}
#' @references Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71.
#' 
#' Chambers, R. and N. Tzavidis (2006): \emph{M-quantile models for small area estimation},
#' Biometrika, 93, 255-268.
#' %@author Enno Tammena \email{tammenae@@hu-berlin.de}
#' @examples
#' print(mq(stack.loss ~ ., stackloss, t=c(0.25,0.5,0.75)))
#' mq(stack.loss ~ ., stackloss, t=c(0.25,0.5,0.75)) #equivalent

print.mq = function(object) {
  if(inherits(object,"mq")==FALSE) stop("Object is not of class mq")
  call<-cat("Call: \n", deparse(object$call), "\n")
  cat("\nNumber of Iterations until Convergence: \n")
  print(object$iterations)
  cat("\nResiduals:\n")
  print(summary(object$residuals))
  cat( "\nCoefficients: \n")

  coef <- round(object$coefficients,4)
  print(coef)
  scale <- round(object$scale,4)
  cat( "\nEstimators of Scale: \n")
  print(scale)
  rsq <- round(object$r_2,2)
  cat( "\nPseudo R-squared: \n")
  print(rsq)
}
