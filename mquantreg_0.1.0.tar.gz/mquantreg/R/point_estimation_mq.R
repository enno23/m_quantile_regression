# Internal documentation -------------------------------------------------------

# Point estimation function

# This function implements the estimation of the pseudo random effects model
# and the monte-carlo approximation to predict
# the desired indicators. See corresponding functions below.

point_estim_mq <- function (framework,
                            fixed,
                            L,
                            keep_data  = FALSE,
                            ...
                            ) {
  #to reduce code, the strings are extracted from the framework
  dep_var <- framework$dep_var
  smp_domains <- framework$smp_domains
  pop_domains <- framework$pop_domains

  # Model estimation, model parameter and parameter of generating model --------

  # Estimation of the pseudo random effects M-quantile model.
  # mmqm function is included in the mquantreg package.
   m_m       <- mmqm(formula=fixed, data=framework$smp_data_dt, ...,  domains = framework$smp_domains)

  #Predict out of sample values
  population_y_hat <- predict(m_m, framework$pop_data_dt)

  # Function G calculates the  error vector based in predicted vs.
  # actual values from the mmqm model.
  # It returns a vector of errors.
  err_sm<-G(m_m, framework$smp_data_dt,dep_var)

  # Monte-Carlo approximation --------------------------------------------------
  if(inherits(framework$threshold, "function")) {
    framework$threshold <-
      framework$threshold(y = as.numeric(framework$smp_data_dt[,..dep_var]))
  }

  # The monte-carlo function returns a data frame of desired indicators.
  indicator_prediction <- monte_carlo_mq(L= L, smp_data=framework$smp_data_dt,pop_data=framework$pop_data_dt, smp_domains=smp_domains,  pop_domains= framework$pop_domains, dep_var=dep_var, err_sm=err_sm, framework=framework, population_y_hat=population_y_hat)

  return(list(ind            = indicator_prediction,
              model          = m_m,
              errors         = err_sm,
              fitted         = population_y_hat
              )
         )
} # End point estimation function


# All following functions are only internal ------------------------------------

# Function to calculate error distribution G-------------------------------------
# unconditional approach (Marchetti et al. 2012)
G<-function(m_object, smp_data,dep_var){
  y_hat_s <- predict(m_object, smp_data)
  err <- as.matrix(smp_data[,..dep_var]) - as.vector(y_hat_s)
}


# Monte-Carlo approximation ----------------------------------------------------

# The function approximates the non-linear indicators.  For description of the  monte-carlo simulation
# see Marchetti et al. (2012)
monte_carlo_mq <- function(L, smp_data, smp_domains,pop_data=pop_data, pop_domains,dep_var=dep_var, err_sm=err_sm, framework=framework, population_y_hat=population_y_hat) {

# generate a data.table with the in-sample values by domain (will be the same in each iteration L)
  direct_data <- data.frame(smp_data[,..dep_var] , smp_data[,..smp_domains])

# Preparing matrices for indicators for the Monte-Carlo simulation
#   quant10s = quant25s = mediane = quant75s = quant90s = ginis = qsrs = pgaps =
#     hcrs = means <- matrix(nrow=framework$N_dom_pop, ncol=L)

  ests_mcmc <- array(dim = c(framework$N_dom_pop,L,length(framework$indicator_names)))

  for (l in 1:L) {

    # Sample with replacement from error vector G
    errors  <- sample(err_sm, framework$N_pop, replace=T)

    # Prediction of population vector y
    # See below for function prediction_y_mq.
    population_df <- prediction_y_mq(errors = errors,  pop_domains=pop_domains, pop_data=pop_data, direct_data=direct_data, population_y_hat=population_y_hat)

    # Calculation of indicators for each Monte Carlo population
    ests_mcmc[,l,] <- matrix(nrow=framework$N_dom_pop, data = unlist(lapply(
    framework$indicator_list, function(f, threshold){matrix(nrow=framework$N_dom_pop,
                                                            data = unlist(tapply(
                                                            population_df[,dep_var],
                                                            population_df[,smp_domains],
                                                            f,
                                                            threshold = framework$threshold,
                                                            simplify = TRUE)),byrow=TRUE)},
                                                            threshold = framework$threshold)))

  } # End for loop

  # Point estimations of indicators by taking the mean

  point_estimates <- data.frame(Domain = unique(framework$pop_domains_vec) ,
                                apply(ests_mcmc, c(3), rowMeans))
  colnames(point_estimates) <- c("Domain", framework$indicator_names)
  return(point_estimates)

} # End monte_carlo_mq

# prediction_y_mq ----------------------------------------------------
# The function prediction_y_mq returns a predicted income vector which can be used
# to calculate indicators. Note that an income vector is predicted WITH
# distinction between in- and out-of-sample domains (contrary to ebp).
prediction_y_mq <- function(errors, pop_domains, pop_data, direct_data, population_y_hat) {
  y_hat_t <- population_y_hat+errors
  auxillary_data <- data.frame(y_hat_t, pop_data[,..pop_domains])
  names(auxillary_data) <- names(direct_data)
  y_pred <- rbind(direct_data, auxillary_data)
  return(y_pred)
} # End prediction_y_mq


