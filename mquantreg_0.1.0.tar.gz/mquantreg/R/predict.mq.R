#' Predict method for Linear M-quantile Model Fits
#'
#'Predicted values for class "mq".
#'
#' @param object	mq object, a result of  \code{\link{mq}}.

#' @param newdata	An optional data frame in which to look for variables with which to predict. If omitted, the fitted values are used.
#' @return The function calculates the predicted values.
#' @export
#' @seealso \code{\link{mq}}
#' @references Breckling, J. and  Chambers, R. (1988): "M-quantiles", Biometrika, 75, 761–71.
#'
#' Chambers, R. and N. Tzavidis (2006): “M-quantile models for small area estimation”,
#'Biometrika, 93, 255–268.
#' %@author Enno Tammena \email{tammenae@@hu-berlin.de}
#' @examples
#' ##Predictions
#' x=rnorm(15)
#' e=rnorm(15)
#' y=x+e
#' df <- data.frame(x=x, y=y)
#' predict(mq(y ~ x, data=df))
#' new <- data.frame(x = seq(-3, 3, 0.5))
#' predict(mq(y ~ x, data=df), new)

predict.mq <- function (object, newdata, na.action = na.pass, ...)
{
  if(inherits(object,"mq")==FALSE) stop("Object is not of class mq")
  if (missing(newdata))
    return(object$fitted)
  else {
    newdata <- cbind(y=rep(0,nrow(newdata)), newdata)
    oldnames <- colnames(object$x)[!colnames(object$x) %in% "(Intercept)"]
    newnames <- colnames(newdata)
    if(any(!oldnames %in% newnames)==TRUE) stop("one or more variable names do not match")
    x <- model.matrix(object$call, newdata)
    y_hat <- NULL
    y <- NULL
    for(t in 1:length(object$tau.values)){
      b <- object$coefficients[,t]
      y_hat <-  cbind(y_hat,x%*%b)
      #2bd  oldclasses(object$x)[!colnames(object$x) %in% "(Intercept)"]
    }
    pred <- as.data.frame(y_hat)
    colnames(pred) <- as.character(object$tau.values)

    return(pred)
  }

}
