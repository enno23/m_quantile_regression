# Internal documentation -------------------------------------------------------


# Function bootstrap_mq_sae conducts the MSE estimation defined in function
# mse_estim_mq (see below)
# The non-parametric boostrap approach can be found in Marchetti et al. (2012, pp. 2889ff)

bootstrap_mq_sae <- function(framework,
                             point_estimates,
                             fixed,
                             L,
                             B,
                             S,
                             parallel_mode,
                             cpus,
                             smoothed,
                             ...
                             ) {
  cat('\r', "Bootstrap started                                                                        ")

  # because the MQ-functions are written for data.table, the dataframes are transformed
  dep_var <- framework$dep_var
  smp_domains <- framework$smp_domains
  pop_domains <- framework$pop_domains

  # The function G_hat calculates and returns the error distribution to sample from.
  G_err <-G_hat(err=point_estimates$errors, smoothed = smoothed)

  start_time = Sys.time()
  if (cpus > 1) {

    cpus <- min(cpus, detectCores())

    parallelStart(mode = parallel_mode, cpus = cpus, show.info = FALSE)

    if (parallel_mode == "socket") {
      clusterSetRNGStream()
    }

    mses <- simplify2array(parallelLapply( xs              = 1:B,
                                           fun             = mse_estim_wrapper_mq,
                                           B               = B,
                                           framework       = framework,
                                           fixed           = fixed,
                                           model           = point_estimates$model,
                                           G_err           = G_err,
                                           pop_data        = framework$pop_data_dt,
                                           smp_data        = framework$smp_data,
                                           pop_domains     = pop_domains,
                                           smp_domains     = smp_domains,
                                           dep_var         = dep_var,
                                           L               = L,
                                           S               = S,
                                            start_time     = start_time,
                                           ...
                                           )
            )
    parallelStop()
  } else{
      mses <- simplify2array(lapply(        X               = 1:B,
                                            FUN             = mse_estim_wrapper_mq,
                                            B               = B,
                                            fixed           = fixed,
                                            framework       = framework,
                                            model           = point_estimates$model,
                                            G_err           = G_err,
                                            pop_data        = framework$pop_data_dt,
                                            smp_data        = framework$smp_data,
                                            pop_domains     = pop_domains,
                                            smp_domains     = smp_domains,
                                            dep_var         = dep_var,
                                            L               = L,
                                            S               = S,
                                             start_time     = start_time,
                                            ...
                                            )
      )
  }

  cat('\r', "Bootstrap completed                                                                      ")
  if(.Platform$OS.type == "windows"){
    flush.console()
  }
  mses <- apply(mses, c(1,2), mean)
  colnames(mses) <- framework$indicator_names
  mses <- data.frame(Domain = unique(framework$pop_domains_vec), mses)

  return(mses)
}

# mse_estim_mq (only internal) ----------------------------------------------------

# The mse_estim_mq function defines all estimations which have to
# be replicated B times for the non-parametric bootstrap approach.
# See Marchetti et al. (2012)

mse_estim_mq <- function(framework,
                         model,
                         G_err,
                         pop_data,
                         smp_data,
                         dep_var,
                         pop_domains,
                         smp_domains,
                         L,
                         S,
                         fixed,
                         ...
                         ) {


  # The function superpopulation returns a data.table with
  # dependend and independent variables as well as the domains

    superpop <- superpopulation_mq(framework = framework,
                                   model     = model,
                                   G_err     = G_err,
                                   pop_data  = pop_data,
                                   smp_data  = smp_data,
                                   dep_var   = dep_var
                                  )

  if (inherits(framework$threshold, "function")){
    framework$threshold <-
      framework$threshold(y = superpop[,..dep_var])
  }
  # Calculate true bootstrap population indicator values
  true_indicators <- matrix(nrow = framework$N_dom_pop,
                            data = unlist(lapply(framework$indicator_list,
                                   function(f, threshold){
                                     matrix(nrow = framework$N_dom_pop,
                                            data = unlist(tapply(as.data.frame(superpop)[,dep_var],
                                                                 as.data.frame(superpop)[,pop_domains], f,
                                                                 threshold = framework$threshold ,
                                                                 simplify = TRUE)),byrow = TRUE)},
                                   threshold = framework$threshold)
                                   )
  )

    colnames(true_indicators) <- framework$indicator_names

    # Monte-Carlo Sampling and Calculations
    mc_results  <- bootstrap_monte_carlo_mq(superpop=superpop,
                                         framework=framework,
                                         S=S,
                                         L=L,
                                         ...,
                                         smp_domains=smp_domains,
                                         fixed=fixed)

  mean_indicators <-   apply(mc_results, c(2), rowMeans)
  # substract mean indicators from each iteration
  dim3 <-sweep(mc_results,1:2,mean_indicators,"-")
  # average squared values over s
  var_B<- apply(dim3^2, c(2), rowMeans)
  # substract true indicators from each iteration
  dim3 <-sweep(mc_results,1:2,true_indicators,"-")
  bias_B<- apply(dim3, c(2), rowMeans)
  mse_B <- var_B+bias_B^2
} # End mse_estim_mq



# Function to calculate error distribution G-------------------------------------
G_hat<-function(err, smoothed){
  if(smoothed==T){
    # Note: there is an issue with np pacakge, thus smoothing doesn't work anymore.
    # # smoothed and unconditional approach (Marchetti et al. 2012)
    # G <- as.data.frame(err-mean(err))
    # bw<-npudensbw(~G$eqIncome,ckertype="epanechnikov")
    # Fhat<-fitted(npudist(bws=bw$bw))
    # G <- G + rnorm(length(G), 0, bw$bw)
  }
  else {
    # unsmoothed and unconditional approach
    G <- err-mean(err)
  }
}


# Superpopulation function -----------------------------------------------------

# Using the error distribution and the estimated mmqm-model a
# superpopulation is constructed.

superpopulation_mq <-  function(framework,
                                model,
                                G_err,
                                pop_data,
                                smp_data,
                                dep_var) {
  smp_data[[dep_var]] <- NULL
  tot_data <- rbind(pop_data, smp_data)
  e_t<- sample(G_err, framework$N_pop+framework$N_smp, replace=T)
  y <- predict(model, tot_data)+e_t
  dt_t <- cbind(y,tot_data)
  colnames(dt_t) <- c(dep_var, colnames(tot_data))
  return(dt_t)
}

# Bootstrap function -----------------------------------------------------

bootstrap_monte_carlo_mq <- function(superpop, framework, S, L, ..., smp_domains, fixed){
# genrate array for Monte-Carlo Result
# careful: S is the last argument here.
mc_results <- array(dim = c(framework$N_dom_pop,length(framework$indicator_names),S))

for (s in 1:S) {
  # stratified sampling of superpop
  superpop$id <- 1:nrow(superpop)
  sampleids <- NULL
  for(i in 1:length(framework$n_smp)){
    sampleid<-sample(subset(superpop, eval(as.name(smp_domains)) == names(table(framework$smp_domains_vec))[i])$id, framework$n_smp[i])
    sampleids<-c(sampleids,sampleid)
  }
  framework$smp_data <- superpop[id %in% sampleids]
  framework$pop_data <- superpop[!id %in% sampleids]
  framework$smp_data$id <- NULL
  framework$pop_data$id <- NULL
  # in contrast to ebp, also the pop_data needs to be replaced in framework!

  # Calculation of indicators for each Monte Carlo sample
  # careful: l is now the last argument!
  # Prediction of indicators with bootstrap sample.
  bootstrap_point_estim <- as.matrix(point_estim_mq(framework,
                                                    fixed,
                                                    L,
                                                    ...
                                      )[[1]][,-1])

  mc_results[,,s] <- bootstrap_point_estim
} # End for loop
return(mc_results)
}

# progress for mse_estim (only internal) -----------------------------------

mse_estim_wrapper_mq <-  function(i,
                                  B,
                                  framework,
                                  model,
                                  G_err,
                                  pop_data,
                                  smp_data,
                                  pop_domains,
                                  smp_domains,
                                  dep_var,
                                  L,
                                  S,
                                  start_time,
                                  boot_type,
                                  seedvec,
                                  fixed,
                                  ...) {

  tmp <- mse_estim_mq(framework  = framework,
                     G_err       = G_err,
                     model       = model,
                     pop_data    = pop_data,
                     smp_data    = smp_data,
                     pop_domains = pop_domains,
                     smp_domains = smp_domains,
                     dep_var     = dep_var,
                     L           = L,
                     S           = S,
                     fixed       = fixed,
                     ...
                     )

  if (i%%10 == 0) {
    if (i != B) {
      delta <- difftime(Sys.time(), start_time, units = "secs")
      remaining <- (delta/i)*(B-i)
      remaining <- unclass(remaining)
      remaining <- sprintf("%02d:%02d:%02d:%02d",
                           remaining %/% 86400,  # days
                           remaining %% 86400 %/% 3600,  # hours
                           remaining %% 3600 %/% 60,  # minutes
                           remaining %% 60 %/% 1) # seconds)

      cat('\r', i, " of ", B, " Bootstrap iterations completed \t Approximately ",
          remaining, " remaining")
      if(.Platform$OS.type == "windows") flush.console()
    }
  }
  return(tmp)
}
