#' Linear M-quantile Regression
#'
#' Fit linear M-quantile regression based on the Huber proposal 2 loss function. This function
#' is a modification of the  \code{\link{rlm}} function in the package \code{\link{MASS}}
#'
#' @param formula	a formula of the form y ~ x1 + x2 + ....
#' @param data a data frame containing the variables in the model.
#' @param k tuning constant used for Huber proposal 2 loss function.
#' @param t vector of tau values specifying the M-quantiles.
#' @param w	a vector of prior weights for each case (for the IWLS procedure).
#' @param case.weights (optional) initial down-weighting for each case.
#' @param var.weights (optional) initial variable weights.
#' @param init (optional) initial values for the coefficients or a
#' method to find initial values or the result of a fit with a coef component.
#' Known methods are "ls" (the default) for an initial least-squares fit using
#' weights w*weights, and "lts" for an unweighted least-trimmed squares fit
#' with 200 samples.
#' @param maxit	the limit on the number of IWLS iterations.
#' @param acc	the accuracy for the stopping criterion.
#' @param test.vec	the stopping criterion is based on changes in this vector.
#' @param sparse returns less results (to save RAM).
#'

#' @return An object of class "mq" which is a list with the following components:
#' \item{fitted.values}{matrix of fitted values per M-quantile.}
#' \item{residuals}{matrix of residuals per M-quantile. }
#' \item{tau.values}{tau values for which regressions were run.}
#' \item{coefficients}{matrix of coefficients per M-quantile.}
#' \item{call}{the formula that was called.}
#' \item{iterations}{number of iterations until convergence per M-quantile.}
#' \item{scale}{results from scale estimation per M-quantile.}
#' \item{iterations}{number of iterations until convergence per M-quantile.}
#' \item{x}{model-matrix of the independent variables.}
#' \item{y}{vector of the dependent variable.}
#' \item{classes}{classes of the independent variables (needed for plotting).}
#' \item{r_2}{pseudo R-squared per M-quantile. Interpret only as an approximate figure.}

#' @export
#' @seealso \code{\link{rlm}}
#' @references Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71.
#'
#' Chambers, R. and N. Tzavidis (2006): \emph{M-quantile models for small area estimation},
#' Biometrika, 93, 255-268.
#' @examples
#' mq(stack.loss ~ ., stackloss, t=c(0.25,0.5,0.75))
#' @import data.table


mq <- function (formula,
                data,
                k = 1.345,
                t = 0.5,
                w = rep(1, nrow(data)),
                case.weights = rep(1, nrow(data)),
                var.weights = rep(1, nrow(data)),
                init = "ls",
                maxit = 30,
                acc = 1e-04,
                test.vec = "resid",
                sparse = TRUE
                #...,
                #psi = psi.huber,
                #scale.est = c("MAD", "Huber", "proposal 2"),
                #method = c("M", "MM"))
){

  # Data manipulation and argument checking ---------------------------------
  mq.check(formula      = formula,
           data         = data,
           test.vec     = test.vec,
           var.weights  = var.weights,
           case.weights = case.weights,
           k            = k,
           sparse       = sparse)

  # standard settings for scale and influence function
  scale.est <- "MAD"
  psi <- psi.huber
  method <- "M"

  data <- as.data.frame(data)
  colclasses <- sapply(model.frame(data), class)

  #extract dependent and independent variables
  dep_var <- gsub(" ", "",unlist(strsplit(paste(formula[2]), "[+]")), fixed = TRUE)
  y <- as.matrix(data[dep_var])
  x <- transform_x(formula, data)
  w <- (w * case.weights)/var.weights


  # Initialization of the IWLS procedure -- ---------------------------------
  if (method == "M") {
    #scale.est <- match.arg(scale.est)
    # paste  other psi functions here, if desired to implement at a later point
    if (is.character(init)) {
      if (init == "ls")
        temp <- lm.wfit(x, y, w, method = "qr")
      else if (init == "lts")
        temp <- lqs.default(x, y, intercept = FALSE, nsamp = 200)
      else stop("init method is unknown")
      coef <- temp$coef
      resid <- temp$resid
    }
    else {
      if (is.list(init))
        coef <- init$coef
      else coef <- init
      resid <- y - x %*% coef
      }
    }
  # paste MM method here, if desired to implement at a later point
  #if (method == "M") {}
  done <- FALSE
  conv <- NULL
  n1 <- nrow(x) - ncol(x)
  #if (scale.est != "MM")
  #Only MAD is used here
    scale <- mad(resid/sqrt(var.weights), 0)
  theta <- 2 * pnorm(k) - 1
  gamma <- theta + k^2 * (1 - theta) - 2 * k * dnorm(k)
  test <- matrix(0, nrow = ncol(x), ncol = length(t))
  twt <- matrix(0, nrow = nrow(x), ncol = length(t))
  tfit <- matrix(0, nrow = nrow(x), ncol = length(t))
  tres <- matrix(0, nrow = nrow(x), ncol = length(t))
  tit <- matrix(0, nrow = nrow(x), ncol = length(t))
  rsq <- matrix(0, nrow = nrow(x), ncol = length(t))
  tscale <- matrix(0, nrow = nrow(x), ncol = length(t))


  # Regression estimation per tau value--------------------------------------
  for(i in 1:length(t)) {
    IWLS_results <- IWLS(maxit        = maxit,
                         test.vec     = test.vec,
                         scale.est    = "MAD",
                         resid        = resid,
                         psi          = psi,
                         tau          = t[i],
                         x            = x,
                         y            = y,
                         var.weights  = var.weights,
                         case.weights = case.weights,
                         acc          = acc,
                         conv         = conv,
                         k            = k
    )
    if (!IWLS_results$done)
      warning(paste("algorithm failed to converge in", maxit,
                    "steps at t = ", t[i]))
    # store results for current tau
    test[, i] <- IWLS_results$coef
    twt[, i] <- IWLS_results$w
    tfit[, i] <- IWLS_results$fit
    tres[, i] <- IWLS_results$resid
    tit[, i] <- IWLS_results$iiter
    tscale[, i] <- IWLS_results$scale
    sst <- sum((y - mean(y))^2)
    ssr <- sum(IWLS_results$resid^2)
    rsq[,i]  <- 1 - (ssr/(sst))
  }
  # colnames and rownames for the results
  rownames(test) <- dimnames(x)[[2]]
  colnames(test) <- as.character(t)
  colnames(tres) <- as.character(t)
  colnames(tit) <- as.character(t)
  colnames(tscale) <- as.character(t)
  colnames(rsq) <- as.character(t)
  if(sparse==TRUE)
  {
    results <- list(fitted.values = tfit,
                    residuals     = tres,
                    tau.values    = t,
                    coefficients  = test,
                    call          = formula,
                    iterations    = tit[1,],
                    scale         = tscale[1,],
                    x             = x,
                    y             = y,
                    classes       = colclasses,
                    r_2           = rsq[1,])
  }  else{

    results <- list(fitted.values = tfit,
                    residuals     = tres,
                    tau.values    = t,
                    t.weights     = twt,
                    coefficients  = test,
                    call          = formula,
                    iterations    = tit[1,],
                    scale         = tscale[1,],
                    x             = x,
                    y             = y,
                    classes       = colclasses,
                    r_2           = rsq[1,])
  }
  class(results) <- "mq"
  return(results)

}


# The following functions are only internal------------------------------------

# IWLS Algorithm---------------------------------------------------------------

IWLS <- function(maxit,
                 test.vec,
                 scale.est = MAD,
                 resid,
                 psi,
                 tau,
                 x,
                 y,
                 var.weights,
                 case.weights,
                 acc,
                 conv,
                 k
                 )
{
  for (iiter in 1:maxit) {
    if (!is.null(test.vec))
      testpv <- get(test.vec)
    #if (scale.est != "MM") {
    #if (scale.est == "MAD")
    scale <- median(abs(resid/sqrt(var.weights)))/0.6745
    #else scale <- sqrt(sum(pmin(resid^2/var.weights,(k*scale)^2))/(n1*gamma))
    if (scale == 0) {
      done <- TRUE
      break
    }
    #}
    w <- psi(resid/(scale * sqrt(var.weights)),k) * case.weights
    #introduce asymmetrie based on tau
    ww <- 2 * (1 - tau) * w
    ww[resid > 0] <- 2 * tau * w[resid > 0]
    w <- ww
    temp <- lm.wfit(x, y, w, method = "qr")
    coef <- temp$coef
    resid <- temp$residuals
    fit <- temp$fitted.values
    if (!is.null(test.vec))
      convi <- irls.delta(testpv, get(test.vec))
    else convi <- irls.rrxwr(x, wmod, resid)
    conv <- c(conv, convi)
    #check if converence critrium is reached
    done <- (convi <= acc)
    if (done)
      break
  } #end for loop
  IWLS_results <- list(coef  = coef,
                       w     = w,
                       fit   = fit,
                       resid = resid,
                       iiter = iiter,
                       scale = scale,
                       done  = done
                       )
  return(IWLS_results)

}


# mq.check-------------------------------------------------------------------
mq.check <- function(formula,
                     data,
                     test.vec,
                     var.weights,
                     case.weights,
                     sparse,
                     k
){
  if (is.null(formula)  || !inherits(formula, "formula"))
    stop('Formula must be a formula object.')
  if (!is.data.frame(data))
    stop('data must be a data.frame or data.table.')
  if (!(any(test.vec == c("resid", "coef", "w", "NULL")) || is.null(test.vec)))
    stop("invalid testvec")
  if (length(var.weights) != nrow(data))
    stop("Length of var.weights must equal number of observations.")
  if (any(var.weights < 0))
    stop("Negative var.weights value.")
  if (length(case.weights) != nrow(data))
    stop("Length of case.weights must equal number of observations.")
  if (!is.numeric(k) || length(k) != 1)
    stop("k needs to be a single numeric value.")
  if (!is.logical(sparse) || length(sparse) != 1){
    stop("sparse must be a logical value.")
    }
}


# transform_x ---------------------------------------------------------------
transform_x <- function(formula, data)
{
  x <- model.matrix(formula, data)
  nmx <- deparse(substitute(x))
  if (is.null(dim(x))) {
    x <- as.matrix(x)
    colnames(x) <- nmx
  }
  else x <- as.matrix(x)
  if (is.null(colnames(x)))
    colnames(x) <- paste("X", seq(ncol(x)), sep = "")
  if (qr(x)$rank < ncol(x))
    stop("x is singular: singular fits are not implemented")
  return(x)
}


# small helper functions-------------------------------------------------------------------
irls.delta <- function(old, new) sqrt(sum((old - new)^2)/max(1e-20, sum(old^2)))
irls.rrxwr <- function(x, w, r) {
  w <- sqrt(w)
  max(abs((matrix(r*w,1,length(r)) %*% x)/sqrt(matrix(w,1,length(r)) %*% (x^2))))/sqrt(sum(w*r^2))
}

# the huber influence function
psi.huber <- function(u, k = 1.345, deriv=0)
{
  if(!deriv) return(pmin(1, k / abs(u)))
  abs(u) <= k
}


# Further functionalities ---------------------------------------------------------

# other psi functions
# psi.hampel <- function(u, a = 2, b = 4, c = 8, deriv=0)
# {
#   U <- pmin(abs(u) + 1e-50, c)
#   if(!deriv) return(ifelse(U <= a, U, ifelse(U <= b, a, a*(c-U)/(c-b) ))/U)
#   ifelse(abs(u) <= c, ifelse(U <= a, 1, ifelse(U <= b, 0, -a/(c-b))), 0)
# }
# psi.bisquare <- function(u, c = 4.685, deriv=0)
# {
#   if(!deriv) return((1  - pmin(1, abs(u/c))^2)^2)
#   t <- (u/c)^2
#   ifelse(t < 1, (1 - t)*(1 - 5*t), 0)
# }

# MM Method
# else if (method == "MM") {
#   scale.est <- "MM"
#   temp <- lqs.default(x, y, intercept = FALSE, method = "S", k0 = 1.548)
#   coef <- temp$coef
#   resid <- temp$resid
#   psi <- psi.bisquare
#   if (length(arguments <- list(...)))
#     if (match("c", names(arguments), nomatch = FALSE)) {
#       c0 <- arguments$c
#       if (c0 > 1.548) {
#         psi$c <- c0
#       }
#       else warning("c must be at least 1.548 and has been ignored")
#     }
#   scale <- temp$scale
# }
# else stop("method is unknown")


# if (!is.function(psi))
#   psi <- get(psi, mode = "function")
# arguments <- list(...)
# if (length(arguments)) {
#   pm <- pmatch(names(arguments), names(formals(psi)), nomatch = 0)
#   if (any(pm == 0))
#     warning(paste("some of ... do not match"))
#   pm <- names(arguments)[pm > 0]
#   formals(psi)[pm] <- unlist(arguments[pm])
# }
