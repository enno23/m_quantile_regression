#' Plot visualization for an mmqm Object
#'
#' Creates  two types of plots of pairwise combinations of the dependent and independent variable that vizualize the pseudo random effects. A list of plots is returned,
#' one for each numeric independent variable which is plotted against the dependent variable. Factor variables are automatically excluded.
#'
#' @param object	mmqm object, a result of  \code{\link{mmqm}}.
#' @param type	either "domain" or "overall". Defaults to domain.
#' @param legend	either \code{TRUE} or \code{FALSE}. Set \code{FALSE} when many domains make the plot unreadable. Defaults to true.
#'
#' type="overall" plots the grid (as specified in mmqm) of M-quantile regression lines over the data.
#' type="domain" plots the regression lines that visualize the pseudo random effects.
#'
#' @return Returns a list of  ggplot2 objects.
#' @export
#' @seealso \code{\link{mmqm}}
#' @references Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71.
#'
#' Chambers, R. and N. Tzavidis (2006): \emph{M-quantile models for small area estimation},
#' Biometrika, 93, 255-268.
#' %@author Enno Tammena \email{tammenae@@hu-berlin.de}
#' @examples
#' m_model <- mmqm(weight ~Time, data=ChickWeight, domains="Diet")
#' plot(m_model, type="overall")
#' plot(m_model, type="domain")


plot.mmqm <- function(object,
                      type="domain",
                      legend=TRUE){
  # Check arguments -------------------------------------------------------------------
  if(inherits(object,"mmqm")==FALSE) stop("Object is not of class mmqm")
  if(legend==T){
    leg <- "right"
  }else if(legend==F){
    leg <- "none"
  }else{
    stop("legend must be either TRUE or FALSE")
  }
  # Plot pseudo random effects per domain----------------------------------------------
  if(type=="domain") {
    intercept <- 0
    #make sure there are no categorical variables and handle the intercept
    xvar <- colnames(object$mq.results$x)
    if ("(Intercept)" %in% xvar ==TRUE){
      intercept<-object$area.coef$`(Intercept)`
      xvar <- xvar[xvar %in% names(which(object$m$classes!= "factor" ))]
    }
    nx <- length(xvar)
    object$area.coef$intercept <- intercept
    yvar <- colnames(object$mq.results$y)
    g=list()
    for(ii in 1:nx){
      g[[ii]] <- ggplot() +  geom_point(data=object$df,  aes_string(y=yvar, x=xvar[ii],  colour = object$dom.name))   + geom_abline(data = object$area.coef,  aes_string(slope =xvar[ii],  intercept = "intercept",  colour = object$dom.name)) + theme(legend.position=leg)
        }
    # Plot the Grid--------------------------------------------------------------------
  } else if(type=="overall") {
    intercept <- 0
    #make sure there are no categorical variables and handle the intercept
    xvar <- colnames(object$mq.results$x)
    if ("(Intercept)" %in% xvar ==TRUE){
      intercept<-object$all.coef$`(Intercept)`
      xvar <- xvar[xvar %in% names(which(object$m$classes!= "factor" ))]
    }
    nx <- length(xvar)
    object$all.coef$intercept <- intercept
    object$all.coef$tau <- as.numeric(rownames(object$all.coef))
    yvar <- colnames(object$mq.results$y)
    g=list()
    for(ii in 1:nx){
      g[[ii]] <- ggplot() +  geom_point(data=object$df, aes_string(y=yvar, x=xvar[ii])) + geom_abline(data = object$all.coef,   aes_string(slope =xvar[ii],   intercept = "intercept", colour = "tau")) +scale_colour_gradientn(colours =  rainbow(5), name=bquote(tau))  + theme(legend.position=leg)
    }
  } else stop("type unknown")
  #return the list of ggplots
  return(g)
}
