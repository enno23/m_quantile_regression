#' Printing Pseudo Linear Mixed M-quantile Model Fits
#'
#' Printing method for class "mmqm".
#'
#' @param object	mmqm object, a result of  \code{\link{mmqm}}.

#' @return The function determines the printing behaviour for  the \code{\link{mmqm}} object.
#' @export
#' @seealso \code{\link{mmqm}}
#' @examples
#' print(mmqm(weight ~Time, data=ChickWeight, domains="Diet"))
#' mmqm(weight ~Time, data=ChickWeight, domains="Diet") #equivalent

print.mmqm <- function(object) {
  if(inherits(object,"mmqm")==FALSE) stop("Object is not of class mmqm")
  cat("Mixed M-quantile Model\n
      Formula: ", deparse(object$call), "\n\n")
  cat("Domains:"   , deparse(object$dom.name), "\n\n")
  cat("Pseudo Random Effects per Domain\n")
  print(object$area.coef)

  cat("\n\nNumber of Observations:",  nrow(object$df))
  cat("\nNumber of Domains:", nlevels(object$domains))

}
