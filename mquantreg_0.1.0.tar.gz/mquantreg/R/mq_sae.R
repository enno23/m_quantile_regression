#' MQ-Models for disaggregated indicators
#'
#' Function \code{mq_sae} estimates indicators using the M-quantile
#' approach. Point predictions of indicators are
#' obtained by Monte-Carlo approximations as proposed by \cite{Marchetti et al. (2012)}. Additionally, mean squared error (MSE)
#' estimation can be conducted by using a non-parametric bootstrap approach. The procedure is based on pseudo random effects
#' that are obtained by linear M-quantile regression as introduced by \cite{Chambers and Tzavidis (2006)}.
#'
#' @param fixed a two-sided linear formula object describing the
#' fixed-effects part of the nested error linear regression model with the
#' dependent variable on the left of a ~ operator and the explanatory
#' variables on the right, separated by + operators. The argument corresponds
#' to the argument \code{fixed} in function \code{\link[mmqm]{mmqm}}.
#' @param pop_data a data frame that needs to comprise the variables
#' named on the right of the ~ operator in \code{fixed}, i.e. the explanatory
#' variables, and \code{pop_domains}.
#' @param pop_domains a character string containing the name of a variable that
#' indicates domains in the population data. The variable can be numeric or
#' a factor but needs to be of the same class as the variable named in
#' \code{smp_domains}.
#' @param smp_data a data frame that needs to comprise all variables named in
#' \code{fixed} and \code{smp_domains}.
#' @param smp_domains a character string containing the name of a variable
#' that indicates domains in the sample data. The variable can be numeric or a
#' factor but needs to be of the same class as the variable named in
#' \code{pop_domains}.
#' @param threshold a number defining a threshold. Alternatively, a threshold may
#' be defined as a \code{function} of \code{y} returning a numeric value. Such a
#' function will be evaluated once for the point estimation and in each iteration
#' of the non-parametric bootstrap. A threshold is needed for calculation e.g. of
#' head count ratios and poverty gaps. The  argument defaults to \code{NULL}.
#' In this case the threshold is set to 60\% of the median of the variable that
#' is selected as dependent variable similarly to the At-risk-of-poverty rate
#' used in the EU (see also \cite{Social Protection Committee 2001}). However,
#' any desired threshold can be chosen.
#' @param L a number determining the number of Monte-Carlo simulations. Defaults
#' to 50.
#' @param ... additional arguments to be passed to the \link[mqmm]{mqmm} function,
#' e.g. the vector of values for the grid, or the tuning parameter for the Huber loss function.

#' @param MSE if \code{TRUE}, MSE estimates using a non-parametric bootstrap approach
#' are calculated (see also \cite{Marchetti et al. (2012)}). Defaults
#' to \code{FALSE}.
#' @param B a number determining the number of bootstrap populations in the
#' non-parametric bootstrap approach (see also \cite{Marchetti et al. (2012)})
#' used in the MSE estimation. Defaults to 10.
#' @param S a number determining the number of samples taken from each
#' bootstrap Population (see also \cite{Marchetti et al. (2012)})
#' used in the MSE estimation. Defaults to 20.

#' @param seed an integer to set the seed for the random number generator. For
#' the usage of random number generation see details. If seed is set to
#' \code{NULL}, seed is chosen randomly. Defaults to \code{123}.
#' @param parallel_mode modus of parallelization, defaults to an automatic selection
#' of a suitable mode, depending on the operating system, if the number of CPUs is
#' chosen higher than 1. For details see \code{\link[parallelMap]{parallelStart}}
#' @param cpus number determining the kernels that are used for the
#' parallelization. Defaults to 1. For details see \code{\link[parallelMap]{parallelStart}}
#' @param custom_indicator a list of functions containing the indicators to be
#' calculated additionally. Such functions must and must only depend on the
#' target variable \code{y} and the \code{threshold}.
#' Defaults to \code{NULL}.
#' @param na.rm if \code{TRUE}, observations with \code{NA} values are deleted
#' from the population and sample data. For the mq_sae procedure complete observations
#' are required. Defaults to \code{FALSE}.
#' @return An object of class "emdi" that provides estimators for regional
#' disaggregated indicators and optionally corresponding MSE estimates. Generic
#' functions such as \code{\link{estimators}}, \code{\link{print}},
#' \code{\link{plot}}, and \code{\link{summary}} have methods that can be used
#' to obtain further information. See \code{\link{emdiObject}} for descriptions
#' of components of objects of class "emdi".
#' @details For Monte-Carlo approximations and in the non-parametric bootstrap
#' approach random number generation is used. Thus, a seed is set by the
#' argument \code{seed}. \cr \cr
#' The set of predefined indicators includes the mean, median, four further quantiles
#' (10\%, 25\%, 75\% and 90\%), head count ratio, poverty gap, Gini coefficient
#' and the quintile share ratio.
#' @references
#' Chambers, R. and N. Tzavidis (2006): M-quantile models for small area estimation,
#' Biometrika, 93, 255-268. \cr \cr
#' Marchetti, S., N. Tzavidis, and M. Pratesi (2012): Non-parametric bootstrap mean
#' squared error estimation for -quantile estimators of small area averages, quantiles and
#' poverty indicators, Computational Statistics & Data Analysis, 56, 2889-2902. \cr \cr
#' Social Protection Committee (2001). Report on indicators in the field of
#' poverty and social exclusions, Technical Report, European Union.
#' @seealso \code{\link{emdiObject}}, \code{\link[mq]{mq}}, \code{\link[mq]{mmqm}},
#' \code{\link{estimators.emdi}}, \code{\link{print.emdi}}, \code{\link{plot.emdi}},
#' \code{\link{summary.emdi}}
#' @examples
#' \dontrun{
#' # Loading data - population and sample data
#' require("emdi") #the datasets are in the emdi package
#' data("eusilcA_pop")
#' data("eusilcA_smp")
#'
#' # Example 1: With default setting but na.rm=TRUE
#' mqemdi_model <- mq_sae(fixed = eqIncome ~ gender + eqsize + cash + self_empl +
#' unempl_ben + age_ben + surv_ben + sick_ben + dis_ben + rent + fam_allow +
#' house_allow + cap_inv + tax_adj, pop_data = eusilcA_pop,
#' pop_domains = "district", smp_data = eusilcA_smp, smp_domains = "district",
#' na.rm = TRUE)
#'
#'
#' # Example 2: With MSE, two additional indicators and MSE estimation
#' mqemdi_model <- mq_sae(fixed = eqIncome ~ gender + eqsize + cash +
#' self_empl + unempl_ben + age_ben + surv_ben + sick_ben + dis_ben + rent +
#' fam_allow + house_allow + cap_inv + tax_adj, pop_data = eusilcA_pop,
#' pop_domains = "district", smp_data = eusilcA_smp, smp_domains = "district",
#' L = 10, MSE = TRUE, B = 5, S=10, custom_indicator =
#' list( my_max = function(y, threshold){max(y)},
#' my_min = function(y, threshold){min(y)}), na.rm = TRUE, cpus = 1)
#' }
#' @export
#' @import data.table
#' @import Hmisc
#' @importFrom parallel detectCores
#' @importFrom parallel clusterSetRNGStream
#' @importFrom stats as.formula dnorm lm median model.matrix na.omit optimize
#' qnorm quantile residuals rnorm sd
#' @importFrom utils flush.console
#' @importFrom stats fitted


mq_sae <- function(fixed,
                   pop_data,
                   pop_domains,
                   smp_data,
                   smp_domains,
                   L = 50,
                   threshold = NULL,
                   MSE = FALSE,
                   #smoothed = FALSE,
                   B = 10,
                   S = 20,
                   seed = 123,
                   parallel_mode = ifelse(grepl("windows",.Platform$OS.type),
                                   "socket", "multicore"),
                   cpus = 1,
                   custom_indicator = NULL,
                   na.rm = FALSE,
                   ...
) {
  # smoothing currently disabled
  smoothed = F

  mq_sae_check1(fixed = fixed, pop_data = pop_data, pop_domains = pop_domains,
             smp_data = smp_data, smp_domains = smp_domains, L = L)

  mq_sae_check2(threshold = threshold, MSE = MSE,  B = B, S = S, smoothed = smoothed,
             custom_indicator = custom_indicator, cpus = cpus,  seed = seed,
             na.rm = na.rm)



  # Save function call ---------------------------------------------------------
  call <- match.call()

  # Set Seed -------------------------------------------------------------------
  if(!is.null(seed)) {
    if (cpus > 1 && parallel_mode != "socket") {
      RNG_kind <- RNGkind()
      set.seed(seed, kind = "L'Ecuyer")
    }
    else
    {
      set.seed(seed)
    }
  }

  # The function framework_mq_sae can be found in script framework_mq_sae.R
  framework <-  framework_mq_sae(pop_data         = pop_data,
                                 pop_domains      = pop_domains,
                                 smp_data         = smp_data,
                                 smp_domains      = smp_domains,
                                 custom_indicator = custom_indicator,
                                 fixed            = fixed,
                                 threshold        = threshold,
                                 na.rm            = na.rm
                                 )



  # Point Estimation -----------------------------------------------------------

  # The function point_estim can be found in script point_estimation.R
  point_estimates <- point_estim_mq(framework  = framework,
                                    fixed      = fixed,
                                    L          = L,
                                    keep_data  = TRUE,
                                    ...
                                    )



  # MSE Estimation -------------------------------------------------------------

  if (MSE == TRUE) {

  # The function bootstrap_mq_sae can be found in script mse_estimation_mq_sae.R
    mse_estimates <-  bootstrap_mq_sae(framework       = framework,
                                       point_estimates = point_estimates,
                                       fixed           = fixed,
                                       L               = L,
                                       B               = B,
                                       S               = S,
                                       parallel_mode   = parallel_mode,
                                       cpus            = cpus,
                                       smoothed        = smoothed,
                                       ...
                                       )



    mq_sae_out <- list(ind          = point_estimates$ind,
                       MSE          = mse_estimates,
                       model        = point_estimates$model,
                       framework    = framework[c("N_dom_unobs",
                                                  "N_dom_smp",
                                                  "N_smp",
                                                  "N_pop",
                                                  "smp_domains",
                                                  "smp_data",
                                                  "smp_domains_vec",
                                                  "pop_domains_vec")],
                    method          = "M-quantile/IRWLS",
                    fixed           = fixed,
                    call            = call
                    )
  } else {

    mq_sae_out <- list(ind          = point_estimates$ind,
                       MSE          = NULL,
                       model        = point_estimates$model,
                       framework    = framework[c("N_dom_unobs",
                                                  "N_dom_smp",
                                                  "N_smp",
                                                  "N_pop",
                                                  "smp_domains",
                                                  "smp_data",
                                                  "smp_domains_vec",
                                                  "pop_domains_vec")],
                       method       = "MQ",
                       fixed        = fixed,
                       call         = call,
                       ...
                    )
  }

  if (cpus > 1 && parallel_mode != "socket") {
    RNGkind(RNG_kind[1]) # restoring RNG type
  }
  class(mq_sae_out) <- c("emdi", "mqmodel")
  return(mq_sae_out)
}
