#' Sample M-quantiles
#'
#' M-quantiles are fitted to univariate samples based on the Huber proposal 2 loss function for asymmetries (quantile-like) between 0 and 1.
#'
#' @param x	numeric vector of univariate observations.
#' @param k the tuning parameter for the loss function.
#' @param tau numeric vector of asymmetries between 0 and 1.
#' @param dec number of decimals remaining after rounding the results.
#' @return returns a numeric vector of M-quantiles.


#' @export
#' @seealso \code{\link{mq}}
#' @seealso \code{\link{quantile}}
#' @references
#' P. J. Huber (1981). \emph{Robust Statistics}. Wiley.
#'
#' Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71.
#' @examples
#' x = rnorm(1000)
#' mquantile(x,tau=c(0.01,0.02,0.05,0.1,0.2,0.5,0.8,0.9,0.95,0.98,0.99))


mquantile <- function (x, k=1.375, tau = seq(0, 1, 0.25), dec = 4) {
  if (!is.vector(x))
    stop("observations are needed in vector form.")
  if (min(tau) < 0 || max(tau) > 1)
    stop("only tau values between 0 and 1 allowed.")
  mqe = 0 * tau
  g = max(abs(x)) * 1e-06
  for (c in 1:length(tau)) {
    p = tau[c]
    if (p == 0)
      mqe[c] = min(x, na.rm = TRUE)
    else if (p == 1)
      mqe[c] = max(x, na.rm = TRUE)
    else {
      m = mean(x)
      for (it in 1:20) {
        e <- x-m
        w = ifelse(e<0, (1-p) * ifelse(abs(e)<=k , 1 ,k/abs(e)), p * ifelse(abs(e)<=k , 1 ,k/abs(e)))
        mnew = sum(x * w)/sum(w)
        de = max(abs(mnew - m))
        m = mnew
        if (de < g)
          break
      }
      mqe[c] = m
    }
  }
  names(mqe) = tau
  mqe = round(mqe, dec)
  return(mqe)
}

