#' Pseudo Mixed M-quantile Models
#'
#' Fit (pseudo) linear mixed M-quantile models to calculate pseudo random effects.
#' These quantities  are obtained based on the finding the average M-quantile
#' regression plane in each domain. This non-parametric procedure
#' was introduced by \cite{Chambers and Tzavidis (2006)}.

#' @param formula	a formula of the form y ~ x1 + x2 + ....
#' @param data a data frame containing the variables in the model.
#' @param domains	name of the variable in data that specifies the domain/group.
#' @param grid	numeric vector with the grid of tau-values. The  argument defaults to \code{seq(0.001,0.999,0.05)}. The 0.5 M-quantile is always calculated.
#' @param ...	additional arguments to be passed to the mq function, e.g. the tuning constant for psi.huber.

#' @return An object of class "mmqm" which is a list with the following components:
#' \item{area.coef}{data.frame with the pseudo random effects per area.}
#' \item{all.coef}{data.frame with the the MQ-coefficients corresponding to the grid. }
#' \item{area.tau}{the average tau values corresponding to the areas.}
#' \item{area.coef}{the results from the MQ-model, see \code{\link{mq}}.}
#' \item{domains}{a vector of domains with length of \code{data}.  }

#' @export
#' @seealso \code{\link[mq]{mq}}
#' @references Breckling, J. and  Chambers, R. (1988). \emph{M-quantiles}. Biometrika 75, 761-71. \cr\cr
#' Chambers, R. and N. Tzavidis (2006): \emph{M-quantile models for small area estimation},
#' Biometrika, 93, 255-268.

#' @examples
#' mmqm(weight ~Time, data=ChickWeight, domains="Diet")
#' @import data.table
#' @import ggplot2



mmqm <- function(formula,
                 data,
                 domains,
                 grid=seq(0.001,0.999,0.05),
                 ...
)
{

  # Data manipulation and argument checking ---------------------------------
  mmqm.check(formula = formula,
             data    = data,
             domains = domains,
             grid    = grid)

  if((0.5 %in% grid)==FALSE){ grid=c(grid,0.5)}
  dff <- as.data.table(data)
  dff$id<-1:nrow(dff)
  setkey(dff, id)
  dff$domains<-dff[,..domains]
  dff$domains<-as.factor(dff$domains)

  # Calculation of the grid of M-quantiles  ---------------------------------
  m<- mq(formula, data=dff, ... , t=grid)

  # Find tau value with interpolation procedure (zerovalinter)---------------
  qo <- apply(m$residuals, 1, zerovalinter, m$tau.values)
  DT <- data.table(tau=qo, id=1:length(qo))
  setkey(DT, id)
  # Save RAM
  m$residuals <- NULL
  m$fitted.values <- NULL

  # Merge vector of tau values with the original data.frame
  dt.merged <- merge(DT[, c('tau', 'id')], dff, by="id")
  setDT(dt.merged)
  #calculate average M-quantile in each domain
  pre <- dt.merged[,  lapply(.SD, mean), by = "domains", .SDcols=c("tau")]
  pre$tau <- round(pre$tau,6)

  # Calculate the Pseudo-Random Effects ------------------------------------
  m_new<- mq(formula, data=dff, ... , t=c(pre$tau))

  # Match the results with the Data
  coefs<-as.data.frame(t(m_new$coefficients))
  coefs$tau<-round(as.numeric(rownames(coefs)),6)
  coefs<-coefs[!duplicated(coefs$tau), ]
  m.area.frame <- as.data.frame(merge(pre,coefs,by="tau"))
  m.area.frame <- m.area.frame[order(m.area.frame$domains),]
  m.area.tau <- m.area.frame[,1:2]
  rownames(m.area.tau) <- c()

  m.area.frame$tau <- NULL
  names(m.area.frame)[names(m.area.frame)=="domains"] <- domains
  rownames(m.area.frame) <- c()

  #rename to original domain name
  mquant.frame <- as.data.frame(t(m$coefficients))
  mquant.frame$tau <- rownames(mquant.frame)
  names(mquant.frame)[names(mquant.frame)=="domains"] <- domains

  results <- list(area.coef  = m.area.frame,
                  all.coef   = mquant.frame,
                  area.tau   = m.area.tau[,c(2,1)],
                  df         = dt.merged,
                  mq.results = m,
                  domains    = dff$domains,
                  call       = formula,
                  dom.name   = domains)
  class(results) <- "mmqm"
  return(results)
}

# The following functions are only internal-----------------------------

# mmqm.check -----------------------------------------------------------

mmqm.check <- function(formula = formula,
                       data    = data,
                       domains = domains,
                       grid    = grid)
{
  if (is.null(formula)  || !inherits(formula, "formula"))
    stop('Formula must be a formula object.')
  if (!is.data.frame(data))
    stop('data must be a data.frame or data.table.')
  if (!is.vector(grid))
    stop("grid is needed in vector form.")
  if (!is.vector(domains))
    stop("domains must be a string.")
  if (! domains %in% colnames(data))
    stop("domains must be a variable in the data.")
  if (min(grid) < 0 || max(grid) > 1)
    stop("only tau values between 0 and 1 allowed.")
}


# zerovalinter -----------------------------------------------------------

zerovalinter <-function(y, x)
{
  if(min(y) > 0) {
    xmin <- x[y == min(y)]
    if(length(xmin) > 0)
      xmin <- xmin[length(xmin)]
    xzero <- xmin
  }

  else {
    if(max(y) < 0) {
      xmin <- x[y == max(y)]
      if(length(xmin) > 0)
        xmin <- xmin[1]
      xzero <- xmin
    }
    else {
      y1 <- min(y[y > 0])
      if(length(y1) > 0)
        y1 <- y1[length(y1)]
      y2 <- max(y[y < 0])
      if(length(y2) > 0)
        y2 <- y2[1]
      x1 <- x[y == y1]
      if(length(x1) > 0)
        x1 <- x1[length(x1)]
      x2 <- x[y == y2]
      if(length(x2) > 0)
        x2 <- x2[1]
      xzero <- (x2 * y1 - x1 * y2)/(y1 - y2)
      xmin <- x1
      if(abs(y2) < y1)
        xmin <- x2
    }
  }
  resu <-  xzero
  resu
}
