#' Summarizing Linear Mixed M-quantile Model Fits
#'
#'Summary method for class "mmqm".
#'
#' @param object	mmqm object, a result of  \code{\link{mmqm}}.

#' @return The function determines the summary behaviour for  the mmqm object.
#' @export
#' @seealso \code{\link{mmqm}}
#' @references Breckling, J. and  Chambers, R. (1988): M-quantiles, Biometrika, 75, 761–71.
#'
#' Chambers, R. and N. Tzavidis (2006): M-quantile models for small area estimation,
#'Biometrika, 93, 255–268.
#' %@author Enno Tammena \email{tammenae@@hu-berlin.de}
#' @examples
#' mqmm_mod <- mmqm(weight ~Time, data=ChickWeight, domains="Diet")
#' summary(mqmm_mod)

summary.mmqm <- function(object) {
  if(inherits(object,"mmqm")==FALSE) stop("Object is not of class mmqm")
  cat("Mixed M-quantile Model\n
      Formula: ", deparse(object$call), "\n\n")
  cat("Domains:"   , deparse(object$dom.name), "\n\n")
  cat("Pseudo Random Effects per Domain\n")
  print(object$area.coef)

  cat("\n\nNumber of Observations:",  nrow(object$df))
  cat("\nNumber of Domains:", nlevels(object$domains))

}
